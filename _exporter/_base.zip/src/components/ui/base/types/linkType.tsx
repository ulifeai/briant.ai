export type linkType = {
  href: string;
  title: string;
};
